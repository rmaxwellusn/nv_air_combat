# gmvn20: Global Map Vietnam 2.0
## non-commercial use
![attribution](https://globalmaps.github.io/globalmaps/attribution.png)
## commercial use
![inquiry](https://globalmaps.github.io/globalmaps/inquiry.png)

## note
Credit: "Global Map of Vietnam ©ISCGM/ Department of Survey and Mapping, Ministry of Nutural Resources and Environment -Vietnam"

Contact: Department of Survey and Mapping, Ministry of Nutural Resources and Environment -Vietnam.

Postal address: Hoang Quoc Viet Road, Cau Giay, Ha Noi, Vietnam 

E-mail: ![email](email.png)

